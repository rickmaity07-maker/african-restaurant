"use client";
import { useLanguage } from "@/lib/languageContext";
import AdminTable from "./AdminTable";

export default function AdminPage({ initial }: { initial: any[] }) {
  const { t } = useLanguage();

  return (
    <>
      <h1 className="text-4xl text-white mb-10">{t.admin.reservations}</h1>
      <AdminTable initial={initial} />
    </>
  );
}