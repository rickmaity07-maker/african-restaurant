"use client";
import React, { createContext, useContext, useState, useCallback } from "react";

type Language = "de" | "en" | "es" | "fr" | "it" | "nl" | "tr" | "pl" | "ru" | "ar" | "zh" | "ja";

type TranslationKeys = {
  common: {
    loading: string;
    searchLang: string;
    noResults: string;
    back: string;
    save: string;
    cancel: string;
    delete: string;
    edit: string;
    confirm: string;
    submit: string;
    required: string;
    optional: string;
    download: string;
    signInRequired: string;
    dayNames: string[];
    dayNamesShort: string[];
  };
  nav: {
    home: string;
    experience: string;
    menu: string;
    reservations: string;
    location: string;
    login: string;
    register: string;
    account: string;
    admin: string;
    logout: string;
    impressum: string;
    privacy: string;
    cookieSettings: string;
    language: string;
  };
  hero: {
    subtitle: string;
    visitUs: string;
    reserveTable: string;
  };
  experience: {
    title: string;
    subtitle: string;
    description: string;
  };
  menu: {
    title: string;
    subtitle: string;
    categories: Record<string, string>;
    price: string;
    popular: string;
  };
  reservations: {
    title: string;
    subtitle: string;
    name: string;
    email: string;
    phone: string;
    guests: string;
    date: string;
    time: string;
    selectTime: string;
    notes: string;
    consent: string;
    submit: string;
    sending: string;
    success: string;
    error: string;
    required: string;
    consentRequired: string;
  };
  location: {
    title: string;
    subtitle: string;
    address: string;
    phone: string;
    hours: string;
    map: string;
  };
  auth: {
    loginTitle: string;
    loginSubtitle: string;
    registerTitle: string;
    email: string;
    password: string;
    name: string;
    phone: string;
    loginBtn: string;
    registerBtn: string;
    forgotPassword: string;
    noAccount: string;
    haveAccount: string;
    signInWith: string;
    google: string;
    facebook: string;
    or: string;
    verifyEmailTitle: string;
    verifyEmailSubtitle: string;
    verifyPhoneTitle: string;
    verifyPhoneSubtitle: string;
    resendCode: string;
    verified: string;
    consent: string;
    consentRequired: string;
    newPassword: string;
    updatePassword: string;
    sendResetLink: string;
    resetLinkSent: string;
    passwordUpdated: string;
  };
  account: {
    title: string;
    profile: string;
    dataPrivacy: string;
    exportData: string;
    deleteAccount: string;
    deleteWarning: string;
    confirmDelete: string;
    cancel: string;
    signOut: string;
    name: string;
    role: string;
    exportDescription: string;
    dangerZone: string;
    signInRequired: string;
  };
  admin: {
    title: string;
    dashboard: string;
    menu: string;
    calendar: string;
    history: string;
    reservations: string;
    settings: string;
    logout: string;
    backToSite: string;
    // Reservations table
    day: string;
    date: string;
    time: string;
    name: string;
    email: string;
    phone: string;
    guests: string;
    tableNumber: string;
    status: string;
    proposeTime: string;
    actions: string;
    pending: string;
    confirmed: string;
    changeRequested: string;
    cancelled: string;
    delete: string;
    send: string;
    close: string;
    previous: string;
    next: string;
    today: string;
    weekOf: string;
    noReservations: string;
    noReservationsYet: string;
    noReservationsThisDay: string;
    noPastReservations: string;
    // Propose time modal
    proposeNewTime: string;
    selectTime: string;
    // Status badges
    confirmedCount: string;
    pendingCount: string;
    // Reservation detail
    table: string;
    partySize: string;
    notes: string;
    viewDetails: string;
    // Menu editor
    addItem: string;
    deleteCategory: string;
    categoryTitle: string;
    categorySubtitle: string;
    itemName: string;
    itemDescription: string;
    itemPrice: string;
    live: string;
    starred: string;
    noItemsYet: string;
    addCategory: string;
    categoryTitlePlaceholder: string;
    categorySubtitlePlaceholder: string;
    deleteCategoryConfirm: string;
    // History
    reservationHistory: string;
    // Calendar
    prev: string;
    calendarView: string;
    // Table headers
    tableNumberHeader: string;
    proposeTimeHeader: string;
    actionsHeader: string;
    error: string;
  };
  footer: {
    rights: string;
    impressum: string;
    privacy: string;
    cookieSettings: string;
  };
  cookieConsent: {
    message: string;
    essentialOnly: string;
    acceptAll: string;
  };
};

type TranslationData = {
  [key in Language]?: TranslationKeys;
};

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  changeLanguage: (newLang: string) => Promise<void>;
  isTranslating: boolean;
  t: TranslationKeys;
  translations: TranslationData;
}

const fallbackTranslations: TranslationData = {
  de: {
    common: {
      loading: "Lädt...",
      searchLang: "Sprache suchen...",
      noResults: "Keine gefunden.",
      back: "Zurück",
      save: "Speichern",
      cancel: "Abbrechen",
      delete: "Löschen",
      edit: "Bearbeiten",
      confirm: "Bestätigen",
      submit: "Absenden",
      required: "Pflichtfeld",
      optional: "Optional",
      download: "Herunterladen",
      signInRequired: "Bitte melden Sie sich an, um auf Ihr Konto zuzugreifen.",
      dayNames: ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"],
      dayNamesShort: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"],
    },
    nav: {
      home: "Startseite",
      experience: "Erlebnis",
      menu: "Speisekarte",
      reservations: "Reservierung",
      location: "Standort",
      login: "Anmelden",
      register: "Registrieren",
      account: "Mein Konto",
      admin: "Admin",
      logout: "Abmelden",
      impressum: "Impressum",
      privacy: "Datenschutz",
      cookieSettings: "Cookie-Einstellungen",
      language: "Sprache",
    },
    hero: {
      subtitle: "Café & Restaurant — Somali & African Cuisine",
      visitUs: "Besuchen Sie uns",
      reserveTable: "Tisch reservieren",
    },
    experience: {
      title: "The Philosophy",
      subtitle: "Rooted in tradition.",
      description: "From Somali chai and specialty coffee at breakfast to Bariis and Baasto platters for dinner, Karmel Café & Restaurant is a sensory journey rooted in Somali and East African tradition, served in the heart of Schweinfurt.",
    },
    menu: {
      title: "Speisekarte",
      subtitle: "Entdecken Sie unsere Gerichte",
      categories: {
        "warme-getranke": "Warme Getränke",
        "kalte-getranke": "Kaltgetränke",
        fruhstuck: "Frühstück",
        pfannkuchen: "Pfannkuchen",
        fladenbrot: "Fladenbrot",
        maisbrei: "Maisbrei",
        snacks: "Snacks",
        spaghetti: "Spaghetti",
        mittagessen: "Mittagessen",
      },
      price: "Preis",
      popular: "Beliebt",
    },
    reservations: {
      title: "Tisch reservieren",
      subtitle: "Join the atmosphere.",
      name: "Vollständiger Name",
      email: "E-Mail",
      phone: "Telefon",
      guests: "Gäste",
      date: "Datum",
      time: "Uhrzeit",
      selectTime: "Uhrzeit wählen",
      notes: "Anmerkungen (optional)",
      consent: "Ich akzeptiere die Verarbeitung meiner Daten für diese Reservierung wie in der Datenschutzerklärung beschrieben.",
      submit: "Reservierung bestätigen",
      sending: "Wird gesendet...",
      success: "Vielen Dank — prüfen Sie Ihre E-Mail zur Bestätigung.",
      error: "Etwas ist schiefgelaufen. Bitte versuchen Sie es erneut.",
      required: "Dieses Feld ist erforderlich.",
      consentRequired: "Sie müssen der Datenschutzerklärung zustimmen, um eine Reservierung vorzunehmen.",
    },
    location: {
      title: "Karmel finden",
      subtitle: "Besuchen Sie uns",
      address: "Adresse",
      phone: "Telefon",
      hours: "Öffnungszeiten",
      map: "Karte",
    },
    auth: {
      loginTitle: "Anmelden",
      loginSubtitle: "Melden Sie sich an, um auf Ihr Konto zuzugreifen.",
      registerTitle: "Konto erstellen",
      email: "E-Mail-Adresse",
      password: "Passwort",
      name: "Vollständiger Name",
      phone: "Telefon (+49...)",
      loginBtn: "Einloggen",
      registerBtn: "Registrieren",
      forgotPassword: "Passwort vergessen?",
      noAccount: "Noch kein Konto?",
      haveAccount: "Bereits ein Konto?",
      signInWith: "Oder anmelden mit",
      google: "Google",
      facebook: "Facebook",
      or: "oder",
      verifyEmailTitle: "E-Mail verifizieren",
      verifyEmailSubtitle: "Geben Sie den 6-stelligen Code ein, der an Ihre E-Mail gesendet wurde.",
      verifyPhoneTitle: "Telefon verifizieren",
      verifyPhoneSubtitle: "Geben Sie den SMS-Code ein, der an Ihre Telefonnummer gesendet wurde.",
      resendCode: "Code erneut senden",
      verified: "Konto verifiziert! Sie können sich jetzt anmelden.",
      consent: "Ich akzeptiere die Verarbeitung meiner Daten wie in der Datenschutzerklärung beschrieben.",
      consentRequired: "Sie müssen der Datenschutzerklärung zustimmen, um ein Konto zu erstellen.",
      newPassword: "Neues Passwort",
      updatePassword: "Passwort aktualisieren",
      sendResetLink: "Reset-Link senden",
      resetLinkSent: "Falls ein Konto für diese E-Mail existiert, wurde ein Reset-Link gesendet.",
      passwordUpdated: "Passwort aktualisiert. Sie können sich jetzt anmelden.",
    },
    account: {
      title: "Mein Konto",
      profile: "Profil",
      dataPrivacy: "Daten & Datenschutz",
      exportData: "Meine Daten exportieren (JSON)",
      deleteAccount: "Konto löschen",
      deleteWarning: "Das Löschen Ihres Kontos entfernt permanent Ihr Profil und Ihre gesamte Reservierungshistorie. Diese Aktion kann nicht rückgängig gemacht werden.",
      confirmDelete: "Löschung bestätigen",
      cancel: "Abbrechen",
      signOut: "Abmelden",
      name: "Name",
      role: "Rolle",
      exportDescription: "Lädt eine JSON-Datei mit Ihren Profilinformationen und Reservierungshistorie herunter.",
      dangerZone: "Gefahrenzone",
      signInRequired: "Bitte melden Sie sich an, um auf Ihr Konto zuzugreifen.",
    },
    admin: {
      title: "Admin Panel",
      dashboard: "Dashboard",
      menu: "Speisekarte",
      calendar: "Kalender",
      history: "Verlauf",
      reservations: "Reservierungen",
      settings: "Einstellungen",
      logout: "Abmelden",
      backToSite: "Zurück zur Website",
      // Reservations table
      day: "Tag",
      date: "Datum",
      time: "Uhrzeit",
      name: "Name",
      email: "E-Mail",
      phone: "Telefon",
      guests: "Gäste",
      tableNumber: "Tisch #",
      status: "Status",
      proposeTime: "Zeit vorschlagen",
      actions: "Aktionen",
      pending: "Ausstehend",
      confirmed: "Bestätigt",
      changeRequested: "Änderung angefragt",
      cancelled: "Storniert",
      delete: "Löschen",
      send: "Senden",
      close: "Schließen",
      previous: "Zurück",
      next: "Weiter",
      today: "Heute",
      weekOf: "Woche vom",
      noReservations: "Keine Reservierungen.",
      noReservationsYet: "Noch keine Reservierungen.",
      noReservationsThisDay: "Keine Reservierungen an diesem Tag.",
      noPastReservations: "Noch keine vergangenen Reservierungen.",
      // Propose time modal
      proposeNewTime: "Neue Zeit vorschlagen",
      selectTime: "Uhrzeit wählen",
      // Status badges
      confirmedCount: "Bestätigt",
      pendingCount: "Ausstehend",
      // Reservation detail
      table: "Tisch",
      partySize: "Personen",
      notes: "Notizen",
      viewDetails: "Details anzeigen",
      // Menu editor
      addItem: "+ Artikel hinzufügen",
      deleteCategory: "Kategorie löschen",
      categoryTitle: "Titel",
      categorySubtitle: "Untertitel",
      itemName: "Name",
      itemDescription: "Beschreibung",
      itemPrice: "Preis",
      live: "Live",
      starred: "★",
      noItemsYet: "Noch keine Artikel.",
      addCategory: "Kategorie hinzufügen",
      categoryTitlePlaceholder: "Titel (z. B. Desserts)",
      categorySubtitlePlaceholder: "Untertitel (z. B. Süße Enden)",
      deleteCategoryConfirm: "Diese ganze Kategorie und ihre Artikel löschen?",
      // History
      reservationHistory: "Reservierungsverlauf",
      // Calendar
      prev: "← Zurück",
      calendarView: "Kalender",
      // Table headers
      tableNumberHeader: "Tisch #",
      proposeTimeHeader: "Zeit vorschlagen",
      actionsHeader: "Aktionen",
      error: "Fehler",
    },
    footer: {
      rights: "Alle Rechte vorbehalten.",
      impressum: "Impressum",
      privacy: "Datenschutz",
      cookieSettings: "Cookie-Einstellungen",
    },
    cookieConsent: {
      message: "Wir verwenden essenzielle Cookies für den Betrieb dieser Seite (Login-Sitzungen). Mit Ihrer Einwilligung laden wir auch Google Maps, wodurch Daten an Google übertragen werden. Details in unserer Datenschutzerklärung.",
      essentialOnly: "Nur essenziell",
      acceptAll: "Alle akzeptieren",
    },
  },
  en: {
    common: {
      loading: "Loading...",
      searchLang: "Search language...",
      noResults: "None found.",
      back: "Back",
      save: "Save",
      cancel: "Cancel",
      delete: "Delete",
      edit: "Edit",
      confirm: "Confirm",
      submit: "Submit",
      required: "Required",
      optional: "Optional",
      download: "Download",
      signInRequired: "Please sign in to access your account.",
      dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    },
    nav: {
      home: "Home",
      experience: "Experience",
      menu: "Menu",
      reservations: "Reservations",
      location: "Location",
      login: "Sign In",
      register: "Register",
      account: "My Account",
      admin: "Admin",
      logout: "Sign Out",
      impressum: "Legal Notice",
      privacy: "Privacy Policy",
      cookieSettings: "Cookie Settings",
      language: "Language",
    },
    hero: {
      subtitle: "Café & Restaurant — Somali & African Cuisine",
      visitUs: "Visit Us",
      reserveTable: "Reserve a Table",
    },
    experience: {
      title: "The Philosophy",
      subtitle: "Rooted in tradition.",
      description: "From Somali chai and specialty coffee at breakfast to Bariis and Baasto platters for dinner, Karmel Café & Restaurant is a sensory journey rooted in Somali and East African tradition, served in the heart of Schweinfurt.",
    },
    menu: {
      title: "Menu",
      subtitle: "Discover our dishes",
      categories: {
        "warme-getranke": "Hot Drinks",
        "kalte-getranke": "Cold Drinks",
        fruhstuck: "Breakfast",
        pfannkuchen: "Pancakes",
        fladenbrot: "Flatbread",
        maisbrei: "Corn Porridge",
        snacks: "Snacks",
        spaghetti: "Spaghetti",
        mittagessen: "Lunch",
      },
      price: "Price",
      popular: "Popular",
    },
    reservations: {
      title: "Reserve a Table",
      subtitle: "Join the atmosphere.",
      name: "Full Name",
      email: "Email",
      phone: "Phone",
      guests: "Guests",
      date: "Date",
      time: "Time",
      selectTime: "Select Time",
      notes: "Notes (optional)",
      consent: "I accept the processing of my data for this reservation as described in the privacy policy.",
      submit: "Confirm Reservation",
      sending: "Sending...",
      success: "Thank you — check your email for confirmation.",
      error: "Something went wrong. Please try again.",
      required: "This field is required.",
      consentRequired: "You must accept the privacy policy to make a reservation.",
    },
    location: {
      title: "Find Karmel",
      subtitle: "Visit Us",
      address: "Address",
      phone: "Phone",
      hours: "Opening Hours",
      map: "Map",
    },
    auth: {
      loginTitle: "Sign In",
      loginSubtitle: "Sign in to access your account.",
      registerTitle: "Create Account",
      email: "Email Address",
      password: "Password",
      name: "Full Name",
      phone: "Phone (+49...)",
      loginBtn: "Sign In",
      registerBtn: "Register",
      forgotPassword: "Forgot Password?",
      noAccount: "Don't have an account?",
      haveAccount: "Already have an account?",
      signInWith: "Or continue with",
      google: "Google",
      facebook: "Facebook",
      or: "or",
      verifyEmailTitle: "Verify Email",
      verifyEmailSubtitle: "Enter the 6-digit code sent to your email.",
      verifyPhoneTitle: "Verify Phone",
      verifyPhoneSubtitle: "Enter the SMS code sent to your phone number.",
      resendCode: "Resend Code",
      verified: "Account verified! You can now sign in.",
      consent: "I accept the processing of my data as described in the privacy policy.",
      consentRequired: "You must accept the privacy policy to create an account.",
      newPassword: "New Password",
      updatePassword: "Update Password",
      sendResetLink: "Send Reset Link",
      resetLinkSent: "If an account exists for that email, a reset link has been sent.",
      passwordUpdated: "Password updated. You can now sign in.",
    },
    account: {
      title: "My Account",
      profile: "Profile",
      dataPrivacy: "Data & Privacy",
      exportData: "Export My Data (JSON)",
      deleteAccount: "Delete Account",
      deleteWarning: "Deleting your account will permanently remove your profile and all reservation history. This action cannot be undone.",
      confirmDelete: "Confirm Deletion",
      cancel: "Cancel",
      signOut: "Sign Out",
      name: "Name",
      role: "Role",
      exportDescription: "Downloads a JSON file with your profile information and reservation history.",
      dangerZone: "Danger Zone",
      signInRequired: "Please sign in to access your account.",
    },
    admin: {
      title: "Admin Panel",
      dashboard: "Dashboard",
      menu: "Menu",
      calendar: "Calendar",
      history: "History",
      reservations: "Reservations",
      settings: "Settings",
      logout: "Sign Out",
      backToSite: "Back to Website",
      // Reservations table
      day: "Day",
      date: "Date",
      time: "Time",
      name: "Name",
      email: "Email",
      phone: "Phone",
      guests: "Guests",
      tableNumber: "Table #",
      status: "Status",
      proposeTime: "Propose Time",
      actions: "Actions",
      pending: "Pending",
      confirmed: "Confirmed",
      changeRequested: "Change Requested",
      cancelled: "Cancelled",
      delete: "Delete",
      send: "Send",
      close: "Close",
      previous: "Previous",
      next: "Next",
      today: "Today",
      weekOf: "Week of",
      noReservations: "No reservations.",
      noReservationsYet: "No reservations yet.",
      noReservationsThisDay: "No reservations on this day.",
      noPastReservations: "No past reservations yet.",
      // Propose time modal
      proposeNewTime: "Propose New Time",
      selectTime: "Select Time",
      // Status badges
      confirmedCount: "Confirmed",
      pendingCount: "Pending",
      // Reservation detail
      table: "Table",
      partySize: "Guests",
      notes: "Notes",
      viewDetails: "View Details",
      // Menu editor
      addItem: "+ Add Item",
      deleteCategory: "Delete Category",
      categoryTitle: "Title",
      categorySubtitle: "Subtitle",
      itemName: "Name",
      itemDescription: "Description",
      itemPrice: "Price",
      live: "Live",
      starred: "★",
      noItemsYet: "No items yet.",
      addCategory: "Add Category",
      categoryTitlePlaceholder: "Title (e.g. Desserts)",
      categorySubtitlePlaceholder: "Subtitle (e.g. Sweet endings)",
      deleteCategoryConfirm: "Delete this whole category and its items?",
      // History
      reservationHistory: "Reservation History",
      // Calendar
      prev: "← Prev",
      calendarView: "Calendar",
      // Table headers
      tableNumberHeader: "Table #",
      proposeTimeHeader: "Propose Time",
      actionsHeader: "Actions",
      error: "Error",
    },
    footer: {
      rights: "All rights reserved.",
      impressum: "Legal Notice",
      privacy: "Privacy Policy",
      cookieSettings: "Cookie Settings",
    },
    cookieConsent: {
      message: "We use essential cookies to run this site (login sessions). With your consent we also load Google Maps, which transfers data to Google. See our privacy policy for details.",
      essentialOnly: "Essential only",
      acceptAll: "Accept all",
    },
  },
};

const STORAGE_KEY = "karmel-language";

export const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

function getInitialLang(): Language {
  if (typeof window === "undefined") return "de";
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY) as Language | null;
    if (stored && stored in fallbackTranslations) return stored;
  } catch {
    // ignore
  }
  return "de";
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>(getInitialLang);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translations, setTranslations] = useState<TranslationData>(fallbackTranslations);

  const setLang = useCallback((newLang: Language) => {
    setLangState(newLang);
    try {
      window.localStorage.setItem(STORAGE_KEY, newLang);
    } catch {
      // ignore
    }
  }, []);

  const buildFullSource = useCallback(() => {
    return fallbackTranslations.de;
  }, []);

  const changeLanguage = async (newLang: string) => {
    if (newLang === lang) return;
    if (newLang === "de" || translations[newLang as Language]) {
      setLang(newLang as Language);
      return;
    }

    setIsTranslating(true);
    try {
      const fullSourceDict = buildFullSource();
      const res = await fetch("/api/translate-ui", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetLang: newLang, sourceDict: fullSourceDict }),
      });
      const data = await res.json();
      if (data.translatedDict) {
        setTranslations((prev) => ({ ...prev, [newLang]: data.translatedDict }));
        setLang(newLang as Language);
      } else if (!res.ok) {
        // Handle any error response (503, 500, 400, etc.)
        console.error("Translation API error:", res.status, data);
        if (res.status === 503 || data.error?.includes("not configured")) {
          console.warn("Translation service not configured. Falling back to German.");
        }
        setLang("de");
      } else {
        throw new Error(data.error || "Translation failed");
      }
    } catch (e) {
      console.error("Translation failed:", e);
      setLang("de");
    } finally {
      setIsTranslating(false);
    }
  };

  const t = (translations[lang] || fallbackTranslations[lang] || fallbackTranslations.de) as TranslationKeys;

  return (
    <LanguageContext.Provider value={{ lang, setLang, changeLanguage, isTranslating, t, translations }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within a LanguageProvider");
  return ctx;
}